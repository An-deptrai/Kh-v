# Lời chúc mẹ 20/10 💗

Một trang web thiệp chúc mừng 20/10, chạy bằng HTML/CSS/JavaScript thuần.

## Chạy thử
Mở `index.html` bằng trình duyệt. Giữ `hoa-20-10.png` cùng thư mục với `index.html` để hiện ảnh thiệp.

## Đưa lên GitHub Pages
1. Tạo một repository mới trên GitHub.
2. Tải `index.html` và `hoa-20-10.png` lên thư mục gốc của repository.
3. Vào **Settings → Pages**.
4. Ở phần **Build and deployment**, chọn **Deploy from a branch**, nhánh `main`, thư mục `/(root)`, rồi nhấn **Save**.
5. Đợi GitHub xuất bản và mở đường link được hiển thị trong mục Pages.
